from .vertice import exec_alg
